#include <iostream>
using namespace std;
int main()
{
    const int size = 10;
    int array[size];
    int temp_array[size] = {0};
    int counter = 1;
    int k = 0;
    cout << "ENTER A VALUES INTO ARRAY :";
    for (int i = 0; i < size; i++)
    {
        cin >> array[i];
    }
    while (counter < size)
    {
        for (int i = 0; i < size - counter; i++)
        {
            if (array[i] < array[i + 1])
            {
                int temp = array[i];
                array[i] = array[i + 1];
                array[i + 1] = temp;
            }

        }
        counter++;
    }
cout<<"MAX TO MIN VALUES INTO INTEGERS :";
    for (int i = 0; i < size; i++)
    {
        cout << array[i]<<"    ";
    }
    return 0;
}