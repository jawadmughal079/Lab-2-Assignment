#include <iostream>

using namespace std;
int main()
{
    int stringLength = 0, wordLength = 0, temp = 0, check = 0;
    int lenghtCounter = 0;
    char string[100], word[10];
    cout << "Enter an array :";
    cin >> string;
    cout << endl
         << "Enter a word which you want to delete :";
    cin >> word;
    while (string[stringLength] != '\0')
    {
        stringLength++;
    }
    while (string[wordLength] != '\0')
    {
        wordLength++;
    }

    for (int i = 0; i < stringLength; i++)
    {
        temp = i;
        for (int j = 0; j < wordLength; j++)
        {
            if (string[i] == word[j])
            {
                i++;
            }
        }

        check = i - temp;

        if (check == wordLength)
        {
            i = temp;
            for (int j = i; j < (stringLength - wordLength); j++)
            {
                string[j] = string[j + wordLength];
                stringLength = stringLength - wordLength;
                string[j] = '\0';
            }
        }
    }
    cout << endl
         << " New string is :" << string;

    return 0;
}
