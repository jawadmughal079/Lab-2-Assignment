#include <iostream>
using namespace std;
int main()
{
    int size;
    int factorial = 1;
    cout << "ENTER A NUMBER PLEASE :";
    cin >> size;
    cout << endl;
    for (int i = 2; i <= size; i++)
    {
        factorial = factorial * i;
    }
    cout << "FACTORIAL OF N NUMBER IS :" << factorial;
    return 0;
}