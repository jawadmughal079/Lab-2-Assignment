#include <iostream>
using namespace std;
int main()
{

    // Decleration and initializes an integer variable
    int numVariable = 12;

    cout << "Variable value :  ";
    cout << numVariable;

    return 0;
}