#include <iostream>
using namespace std;
int main()
{

    const int size = 5;
    int array[size];
    cout << "ENTER A VALUES INTO ARRAY :";
    for (int i = 0; i < size; i++)
    {
        cin >> array[i];
    }
    int key;
    bool flag = 0;
    cout << "ENTER A NUMBER TO SEARCH :";
    cin >> key;
    for (int i = 0; i < size; i++)
    {
        if (key == array[i])
        {
            cout << key << " present at " << i << " index";
            flag = 1;
            break;
        }
    }
    if (flag == 0)
    {
        cout << "not found !";
    }

    return 0;
}