#include <iostream>
using namespace std;
int main()
{
    const int size = 10;
    int array[size];
    cout << "ENTER A VALUES INTO ARRAY :";
    for (int i = 0; i < size; i++)
    {
        cin >> array[i];
    }
    int min = array[0];
    for (int i = 0; i < size; i++)
    {
        if (min < array[i])
        {
            min = array[i];
        }
    }
    cout << "MAX VALUE OF ARRAY IS :" << min;
    return 0;
}