#include <iostream>
using namespace std;
int main()
{

    int num;
    cout << "ENTER A NUMBERS PLEASE :";
    cin >> num;
    int sum = 0;
    int min = num;
    int max = num;
    int counter = 0;
    while (num != -999)
    {

        sum += num;
        counter++;
        if (min > num)
        {
            min = num;
        }
        if (max < num)
        {
            max = num;
        }

        cout << "ENTER A NUMBER PLEASE ENTER AGAIN :";
         cin >> num;
    }

    cout << endl;
    cout << " The sum of all integers :" << sum;
    cout << endl;
    cout << " Total number of entered integers  :" << counter;
    cout << endl;
    cout << " The largest integer :" << max;
    cout << endl;
    cout << "  The smallest integer :" << min;
    cout << endl;
    return 0;
}