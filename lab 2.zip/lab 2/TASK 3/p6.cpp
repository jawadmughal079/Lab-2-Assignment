#include <iostream>
using namespace std;
int main()
{
    const int size = 100;
    char array1[size];
    char array2[size];
    int counter1 = 0;
    int counter2 = 0;
    cout << "ENTER A STRING 1";

    cin >> array1;

    cout << "ENTER A STRING 2";

    cin >> array2;

    while (array1[counter1] != '\0')
    {
        counter1++;
    }

    while (array2[counter2] != '\0')
    {
        counter2++;
    }

    int flag = 0;
    if (counter1 != counter2)
    {
        cout << "false";
    }
    else
    {
        for (int i = 0; i<counter2; i++)
        {

            if (array1[i] == array2[i])
            {
                flag = 1;
            }
            else
            {
                flag = 0;
                cout << "false";
                break;
            }
        }
        if (flag == 1)
        {
            cout << "true";
        }
    }
    return 0;
}