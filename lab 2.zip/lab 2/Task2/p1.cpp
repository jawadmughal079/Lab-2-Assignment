#include <iostream>
using namespace std;
int main()
{

  for (int i = 1; i <=10; i++)
  {
     cout<<10<<"*"<<i<<" = "<<10*i;
     cout<<endl;
  }

    return 0;
}