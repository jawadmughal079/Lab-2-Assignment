#include <iostream>
using namespace std;
int main()
{

    char array[1000];
    int counter = 0;
    cout << "ENTER A STRING :";
    cin >> array;

    while (array[counter] != '\0')
    {
        counter++;
    }
    cout<<"total size of array is :" << counter;
    return 0;
}