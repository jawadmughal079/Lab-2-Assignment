#include <iostream>
using namespace std;
int main()
{
    int sum = 0;

    for (int i = 1; i <= 100; i++)
    {
        if (i % 2 == 1)
        {
            cout << i << "    ";
            sum += i;
        }
    }
    cout << "\nTOTAL SUM OF ODD INTEGERS FROM 1 TO 100 : " << sum;
    return 0;
}