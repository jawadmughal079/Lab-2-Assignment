#include <iostream>
using namespace std;
int main()
{


    int numVariable;

    cout << "Enter Variable Value : ";
    cin >> numVariable;

    cout << "Variable value Entered : ";
    cout << numVariable;

    system("pause>0");
}