#include <iostream>
using namespace std;
int main()
{

    int Price, Quantity;
    int valueOfWheat;
    int valueOfRice;
    int valueOfSugar;

    // wheat
    cout << "Enter a value of wheat : ";
    cin >> Price;
    cout << "Enter a Quantity of wheat : ";
    cin >> Quantity;
    valueOfWheat = Price * Quantity;
    //RICE
    cout << "Enter a value of Rice : ";
    cin >> Price;
    cout << "Enter a Quantity of Rice : ";
    cin >> Quantity;
    valueOfRice = Price * Quantity;
    // sugar
    cout << "Enter a value of Sugar : ";
    cin >> Price;
    cout << "Enter a Quantity of Sugar : ";
    cin >> Quantity;
    valueOfSugar = Price * Quantity;

    cout << "--------------------------------------------------------------------------\n";
    cout << "Value Of Wheat: " << valueOfWheat;
    cout << endl;
    cout << "Value Of Rice: " << valueOfRice;
    cout << endl;
    cout << "Value Of Sugar: " << valueOfSugar;
    cout << endl;
    cout << "--------------------------------------------------------------------------\n";
    return 0;
}